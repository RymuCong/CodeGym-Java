package service;
import model.Student;

public interface IStudentService {
    Student[] findAll();
}
